# 总共两个方案，分为方案A和方案B
#### *需要对两个方案中的6个不同点进行对比，可对比的点分别为graph 1、graph 2、graph 3、graph 4、graph 6&7、graph 8*

## **Graph one：来自不同学校的不同性别的占比**
#### 方案A
* 使用pie chat，一共只有两所学校，所以饼图一共有4块，每一块代表某个学校中某性别人数的比例。使用的字段为：[school，sex]。
  * 示例图：
  * ![avatar](11-a.png)
#### 方案B
* 使用stacked bar chart。一共只有两所学校，所以只有两个bar。每个bar由男性和女性数量组成。使用的字段为：[school，sex]。
  * 示例图：
  * ![avatar](11-b.png)

## **Graph two：所有学生不同性别的年龄分布**
#### 方案A
* 使用stack bar chart，横坐标为年龄，纵坐标为人数。由数据集可知年龄分布为15到22岁。每个bar由男性和女性数量组成。使用的字段为：[age，sex]。
  * 示例图：
  * ![avatar](12-a.png)
#### 方案B
* 使用clustered bar chart，横坐标为年龄，纵坐标为人数。由数据集可知年龄分布为15到22岁。某个年龄的男性数量和女性数量的两个bar组成一个cluster。使用的字段为：[age，sex]。
  * 示例图：
  * ![avatar](12-b.png)

## **Graph three：G3成绩分布直方图**
#### 方案A
* 使用histogram，横坐标为G3成绩分数，纵坐标为人数。使用所有来自两所学校的所有学生的成绩数据。使用的字段为：[G3]。
  * 示例图：
  * ![avatar](13-a.png)
#### 方案B
* 使用cluster histogram，横坐标为G3成绩分数，纵坐标为人数。每个学校的学生的成绩作为一个分布，一共有两个分布。使用的字段为：[G3，school]。
  * 示例图：
  * ![avatar](13-b.png)

## **Graph four：父母的受教育程度与G3成绩的关系**
#### 方案A
* 使用heat map，横纵坐标分别为父亲的受教育程度和母亲的受教育程度，每一个grid代表所有家庭成分为以上组成方式的学生的平均G3成绩。使用的字段为：[G3，Medu，Fedu]。
  * 示例图：
  * ![avatar](14-a.png)
#### 方案B
* 使用parallel coordinates，一共有三个轴，每个轴代表父亲受教育程度、母亲受教育程度、G3成绩。使用的字段为：[G3，Medu，Fedu]。
  * 示例图：
  * ![avatar](14-b.png)

## **Graph five：父母的工作与G3成绩的关系（两个方案中使用同一张图）**
* 使用heat map，横纵坐标分别为父亲工作和母亲工作，每一个grid代表所有家庭成分为以上组成方式的学生的平均G3成绩。使用的字段为：[G3，Mjob，Fjob]。
  * 示例图：
  * ![avatar](15.png)

## **Graph six：缺席次数和G3成绩的关系&缺席次数分布**
#### 方案A
* 缺席次数和G3成绩的关系使用折线图，横坐标为缺席次数（从小到大排列），纵坐标为该缺席次数学生的平均G3成绩。由数据即可知缺席次数为0-32，有部分缺失数据。使用的字段为：[G3，absences]。
  * 示例图：
  * ![avatar](16-a-1.png)
* 缺席次数分布使用折线图。使用的字段为：[G3，absences]。
  * 示例图：
  * ![avatar](16-a-2.png)
#### 方案B
* 缺席次数和G3成绩的关系使用bar chart，横坐标为缺席次数（从小到大排列），纵坐标为该缺席次数学生的平均G3成绩。由数据即可知缺席次数为0-32，有部分缺失数据。使用的字段为：[G3，absences]。
  * 示例图：
  * ![avatar](16-b-1.png)
* 缺席次数分布使用bar chart。使用的字段为：[G3，absences]。
  * 示例图：
  * ![avatar](16-b-2.png)

## **Graph seven：学习时间和G3成绩的关系&学习时间分布**
#### 方案A
* 学习时间和G3成绩的关系使用折线图，横坐标为学习时间所代表的区间（从小到大排列），纵坐标为该学习时间的学生的平均G3成绩。使用的字段为：[studytime，G3]。
  * 示例图：
  * ![avatar](17-a-1.png)
* 学习时间分布使用折线图。使用的字段为：[studytime，G3]。
  * 示例图：
  * ![avatar](17-a-2.png)
#### 方案B
* 学习时间和G3成绩的关系使用bar chart，横坐标为学习时间所代表的区间（从小到大排列），纵坐标为该学习时间的学生的平均G3成绩。使用的字段为：[studytime，G3]。
  * 示例图：
  * ![avatar](17-b-1.png)
* 学习时间分布使bar chart。使用的字段为：[studytime，G3]。
  * 示例图：
  * ![avatar](17-b-2.png)

## **Graph eight：其他定量指标和G3成绩的关系**
#### 方案A
* 我们将学生的成绩高低划分为了5个等级。对于每个等级，使用parallel coordinates进行可视化，因此总共有五张图。使用的字段为：[traveltime，freetime，goout，Walc，health]。
  * 示例图：
  * ![avatar](18-a.png)
#### 方案B
* 我们将学生的成绩高低划分为了5个等级。使用radar chart，总共一张图。使用的字段为：[traveltime，freetime，goout，Walc，health]。
  * 示例图：
  * ![avatar](18-b.png)

